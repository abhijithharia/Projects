/*
Name : Abhijith R
Date : 02/03/2024
Description : Steganography
Sample Execution :

1. Encoding

$ ./a.out -e beautiful.bmp secret.txt stego.bmp
ENCODING SELECTED
Read and validate encode arguments is a success

- - - - - - - Started Encoding - - - - - - -

INFO : Opening required files -> Success
------>Width = 1024
------>Height = 768
INFO : Checking Capacity -> Success
INFO : Copiying BMP header -> Success
INFO : Encoding Magic string -> Success
INFO : Encoding secret file extn size -> Success
INFO : Encoding secret file extn -> Success
INFO : Encoding secret file size -> Success
INFO : Encoding secret file data -> Success
INFO : Copiying remaining data -> Success

++++++------Encoding Succesfull------++++++

2. Decoding

$ ./a.out -d stego.bmp decode.txt
DECODING SELECTED
Read and validate decode arguments is a success

- - - - - - - Started Decoding - - - - - - -

INFO : Opening Files -> Success
INFO : Decoding magic string -> Success
INFO : Decoding file extension size -> Success
INFO : Decoding Secret File Extension -> Success
INFO : Decoded secret file size -> Success
INFO : Decoding secret file data -> Success

++++++------Decoding Succesfull-------++++++
*/

#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include "decode.h"

/* Passing arguments through command line arguments */
int main(int argc, char *argv[])
{
    // Function call for check operation type
    if (check_operation_type(argv) == e_encode)
    {
        printf("ENCODING SELECTED\n");

        // Declare structure variable
        EncodeInfo encInfo;
        // Read and validate encode arguments 
        if (read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("Read and validate encode arguments is a success\n");
			printf("\n");
            printf("- - - - - - - Started Encoding - - - - - - -\n");
			printf("\n");

            // Function call for encoding
            if (do_encoding(&encInfo) == e_success)
            {
				printf("\n");
                printf("++++++------Encoding Succesfull------++++++\n");
				printf("\n");
            }
            else
            {
                printf("Failed to encode\n");
                //return -1;
                return e_failure;
            }
        }
        else
        {
            printf("Read and validate encode arguments is a failure\n");
            //return -1;
            return e_failure;
        }
    }
    // Function call for check operation type
    else if (check_operation_type(argv) == e_decode)
    {
        printf("DECODING SELECTED\n");

        // Declare structure variables
        DecodeInfo decInfo;
        if (read_and_validate_decode_args(argv, &decInfo) == d_success)
        {
            printf("Read and validate decode arguments is a success\n");
			printf("\n");
            printf("- - - - - - - Started Decoding - - - - - - -\n");
			printf("\n");

            // Function call for do decoding
            if (do_decoding(&decInfo) == d_success)
            {
				printf("\n");
                printf("++++++------Decoding Succesfull-------++++++\n");
				printf("\n");
            }
            else
            {
                printf("Decoding Failed\n");
               // return -1;
                 return e_failure;
            }
        }  
        else
        {
            printf("Read and validate decode arguments is a failure\n");
            //return -1;
             return e_failure;
        }
    } 
    else
    {
        printf("Invalid option\nKindly pass for\nEncoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\nDecoding: ./a.out -d stego.bmp decode.txt\n");
    }
    return 0;
}
